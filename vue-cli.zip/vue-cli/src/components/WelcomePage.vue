<template>
    <v-main class="list">
        <v-list-item-content>
            <v-list-item-title class="headline">Tugas Besar</v-list-item-title>
        </v-list-item-content>
        <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
            <a>Login</a>
            <a>Register</a>
            <a>Terms</a>
        </div>  
        <v-app-bar color="#d66700" dark>

        </v-app-bar>
    </v-main>
</template>